
const BASE_URL = "http://35.154.28.156";

export default BASE_URL;
