const config = {
    API_URL: process.env.REACT_APP_API_URL,
    API_TOKEN: "714|z9wobLqS9b1teSOH3Sj1gkoaJ8HYH0GtmP8A5S98f5476199"
};

export default config;
