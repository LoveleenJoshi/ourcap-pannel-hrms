const config = {
    API_URL: process.env.REACT_APP_API_URL,
    API_TOKEN: "1239|JloFJtSlSR4MLtOlirVkTOM27lxiKDDExM4vuUrJbee6b85b"
};

export default config;
