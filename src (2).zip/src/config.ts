const config = {
    API_URL: process.env.REACT_APP_API_URL,
    API_TOKEN: "1236|j80BiVL9dnAwlrSh2InFyfpWL7GCc4AWkGfGRZK648144641"
};

export default config;
