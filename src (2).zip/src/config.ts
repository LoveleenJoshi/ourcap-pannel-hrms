const config = {
    API_URL: process.env.REACT_APP_API_URL,
    API_TOKEN: "729|pkEbCh0YmAOtJgjfr73AT5A1eqba4F9UKTs6o5Iy53a2945c"
};

export default config;
