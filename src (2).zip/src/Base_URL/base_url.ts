
const BASE_URL = "https://app.ourcap.app";
//  const BASE_URL = "";
export default BASE_URL;
